package printer;

public interface Printer {
    public void print();
}
