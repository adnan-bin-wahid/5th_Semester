package printer;

import java.util.HashMap;
import java.util.Map;

public class Printers{
    private static Map<String,Printers> instances = new HashMap<>();
    private String deptName;

    private Printers(String name) {
        this.deptName = name;
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    public static Printers getPrinterForDepartment(String name) {
        if (instances.containsKey(name)) {
            return instances.get(name);
        } else {
            Printers newPrinter = new Printers(name);
            instances.put(name, newPrinter);
            return newPrinter;
        }
    }

    public static void print(String s){
        System.out.println(s);
    }

}
