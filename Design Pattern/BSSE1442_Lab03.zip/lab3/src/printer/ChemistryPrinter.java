package printer;

public class ChemistryPrinter implements Printer{
    private static ChemistryPrinter instance;
    private String value;

    private ChemistryPrinter(String Value){
        try{
            Thread.sleep(1000);
        }catch (InterruptedException ex){
            ex.printStackTrace();
        }
        this.value = value;
    }

    public static ChemistryPrinter getInstance(String value){
        if(instance == null){
            instance = new ChemistryPrinter(value);
        }
        return instance;
    }
    @Override
    public void print() {
        System.out.println("ChemistryPrinter is Writing---");
    }
}
