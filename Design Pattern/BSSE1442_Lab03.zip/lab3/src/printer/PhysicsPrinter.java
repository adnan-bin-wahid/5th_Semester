package printer;

public class PhysicsPrinter implements Printer{
    private static PhysicsPrinter instance;
    private String value;

    private PhysicsPrinter(String Value){
        try{
            Thread.sleep(1000);
        }catch (InterruptedException ex){
            ex.printStackTrace();
        }
        this.value = value;
    }

    public static PhysicsPrinter getInstance(String value){
        if(instance == null){
            instance = new PhysicsPrinter(value);
        }
        return instance;
    }
    @Override
    public void print() {
        System.out.println("PhysicsPrinter is Writing---");
    }
}
