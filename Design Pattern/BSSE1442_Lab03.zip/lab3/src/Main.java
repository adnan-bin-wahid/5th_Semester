import printer.Printers;

public class Main {
    public static void main(String[] args) {
        Printers physicsPrinter = Printers.getPrinterForDepartment("Physics Department");
        Printers.print("Physics Exam Paper");

        Printers mathPrinter = Printers.getPrinterForDepartment("Math Department");
        Printers.print("Math Assignment");


        Printers physicsPrinter2 = Printers.getPrinterForDepartment("Physics Department");
        Printers.print("Physics Lab Report");

        System.out.println("Same printer for Physics: " + (physicsPrinter == physicsPrinter2));  // Should print: true
    }
}