package department;

import printer.PhysicsPrinter;
import printer.Printer;

public class Physics extends Department {
    public Physics(String name){
        this.deptName = name;
    }

    @Override
    public void print() {
        Printer p = PhysicsPrinter.getInstance("Call From Physics Department. \n");
        p.print();
    }
}


