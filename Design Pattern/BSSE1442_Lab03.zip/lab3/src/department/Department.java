package department;

import printer.Printer;

public abstract class Department {
    String deptName;
    public void print(){}
}
