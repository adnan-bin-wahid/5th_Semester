package creator;

import product.Device;

public abstract class Factory {
    public abstract Device createDevice();
}
