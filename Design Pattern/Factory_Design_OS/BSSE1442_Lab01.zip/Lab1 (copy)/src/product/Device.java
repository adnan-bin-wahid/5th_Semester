package product;

public interface Device {
    public void powerOff();
    public void powerOn();
}
